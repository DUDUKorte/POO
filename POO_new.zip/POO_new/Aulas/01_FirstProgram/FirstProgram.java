//Primeiro programa em java upado para o github
/*
 * IFPR - Campus Cascavel
 * Curso: Técnico em informática
 * Disciplina: Programação orientada à objetos
 * Professor: Nelson Bellincanta
 * Data da criação: 16/03/2022
 */

 //Declaração da classe FirstProgram
 public class FirstProgram{ //Primeira letra de classe smpre deve ser maiúscula
    //Declaração do método main, que inicia o programa
    public static void main(String[] args){
        System.out.println("Hello World!");
    } //Fim do main
 } //Fim da calsse FirstProgram

 /*
  Java não tem == em string
  Se usa <string>.equals(<string2>)
  Para comprar strings

  --Caracteres eseciais--
  \n quebra linha
  \r retorno de carro
  \b backspace
  \t tabulação
  \f nova página(formfeed)
  \' coloca ''
  \" coloca ""
  \\ ???
  --------------------------------------------------------
  
  

  */